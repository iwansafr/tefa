<link href="<?php echo base_url().'templates/land_page/'; ?>css/landing-page.css" rel="stylesheet">
<link href="<?php echo base_url().'templates/land_page/'; ?>css/style.css" rel="stylesheet" type="text/css">
