<?php
function admin_function()
{
	return 'testing';
}