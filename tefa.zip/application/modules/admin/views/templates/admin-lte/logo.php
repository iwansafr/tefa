<!-- Logo -->
<a href="<?php echo base_url().'admin' ?>" class="logo">
<!-- mini logo for sidebar mini 50x50 pixels -->
	<span class="logo-mini">tefa</span>
	<!-- logo for regular state and mobile devices -->
	<span class="logo-lg"><i class="fa fa-folder-o"></i> tefa</span>
</a>