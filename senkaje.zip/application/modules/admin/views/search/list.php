<div class="row">
	<div class="col-md-12">
		<h2>content</h2>
		<?php $this->load->view('content/list') ?>
	</div>
	<div class="col-md-12">
		<h2>category</h2>
		<?php $this->load->view('content/category_list') ?>
	</div>
	<div class="col-md-12">
		<h2>menu</h2>
		<?php $this->load->view('menu/list') ?>
	</div>
	<div class="col-md-12">
		<h2>menu position</h2>
		<?php $this->load->view('menu/position_list') ?>
	</div>
	<div class="col-md-12">
		<h2>product</h2>
		<?php $this->load->view('product/list') ?>
	</div>
</div>